import json
import os
import fitz
from PIL import Image

def extract_pdf_content(pdf_path):
    doc = fitz.open(pdf_path)
    text = ""
    pdf_metadata = []

    for page_num, page in enumerate(doc):
        text += page.get_text()
        images = []
        for img_index, img in enumerate(page.get_images(full=True)):
            xref = img[0]
            base_image = doc.extract_image(xref)
            image_bytes = base_image["image"]
            image_ext = base_image.get("ext", "png")
            image_file_name = f"data/images/image_page{page_num+1}_{img_index+1}.{image_ext}"
            with open(image_file_name, "wb") as f:
                f.write(image_bytes)
            images.append(image_file_name)
            # print(images)

        # add text & image from each page
        pdf_metadata.append({
            "page_number": page_num,
            "image_filename": images,
            "text": text
        })

    # dump the metadata into json
    metadata_path = os.path.join("data", "metadata.json")
    with open(metadata_path, "w") as f:
        json.dump(pdf_metadata, f, indent=2)


extract_pdf_content("C:/Users/Arghya/Downloads/040823-SBI Analyst Presentation Q1FY24 Final.pdf")
