import json
import os
import chromadb
import tiktoken
import nltk
from openai import OpenAI
import chromadb.utils.embedding_functions as embedding_functions
from chromadb.config import Settings
from nltk.corpus import stopwords
import polars as pl

# Download NLTK stopwords if you haven't already
nltk.download('stopwords')

# Set your API keys as environment variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["CHROMA_OPENAI_API_KEY"] = "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"


def remove_stop_words(text):
    filtered_text = ""
    if text:
        stop_words = set(stopwords.words('english'))  # You can change the language if needed
        words = text.split()
        filtered_text = " ".join([word for word in words if word.lower() not in stop_words])
    return filtered_text


def load_data_vectordb():
    # Load the metadata json
    # with open(os.path.join("data", "metadata.json"), "r") as f:
    #     page_data = json.load(f)

    raw_g_data = pl.read_csv("./inputs/TeePublic_review.csv", encoding="ISO-8859-1")
    raw_data = raw_g_data[:10]
    raw_data = raw_data.with_row_count("index")
    raw_data.drop_nulls(subset=["review"])

    # Chroma config for persistent data
    CHROMA_SERVER_HOST = "localhost"
    CHROMA_SERVER_PORT = 8080
    COLLECTION_NAME = "articles"

    # Initialize the Chroma client
    chroma_client = chromadb.HttpClient(host=CHROMA_SERVER_HOST, port=CHROMA_SERVER_PORT)
    collection = chroma_client.get_or_create_collection(name=COLLECTION_NAME)

    # Initialize OpenAI embedding function
    openai_ef = embedding_functions.OpenAIEmbeddingFunction(
        model_name="text-embedding-3-small"
    )

    # setup the meta data
    metadata = {
        "review_label": raw_data['review-label'][0],
        "store_location": raw_data['store_location'][0]
    }

    # Remove stop words from the text
    text = remove_stop_words(raw_data['review'][0])
    vectors = openai_ef(text)
    # Store data in Chroma DB
    collection.add(
        ids=['id1'],
        embeddings=vectors,
        documents=[raw_data['review'][0]],
        metadatas=[metadata]
    )

    # Add the rest of the data
    rest_of_articles = [remove_stop_words(raw_data) for raw_data in raw_data['review'][1:].to_list()]
    vectors_list = openai_ef(rest_of_articles)
    # generate the ids
    ids = [f"id{x}" for x in raw_data['index'][1:].to_list()]
    # Push each document entry

    # Store data in Chroma DB
    collection.add(
        ids=ids,
        embeddings=vectors_list,
        documents=rest_of_articles
    )


# Load data into the vector database
load_data_vectordb()
