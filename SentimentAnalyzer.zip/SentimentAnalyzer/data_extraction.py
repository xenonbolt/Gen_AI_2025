import os
from idlelib.tree import wheel_event

import chromadb
import streamlit as st
from openai import OpenAI
import chromadb.utils.embedding_functions as embedding_functions

# Set your API keys as environment variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["CHROMA_OPENAI_API_KEY"] = "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"

# Initialize chromadb client
client = chromadb.HttpClient(host="localhost", port=8080)

# Initialize OpenAI embedding function
openai_ef = embedding_functions.OpenAIEmbeddingFunction(model_name="text-embedding-3-small")


def query_chroma(user_query, collection_name = "articles", n_results = 5):
    try:
        collection = client.get_collection(collection_name)
    except Exception as e:
        collection = None
        print(f"Error: {e}")
        return []

    try:
        query_embedding = openai_ef([user_query])
        results = collection.query(
            n_results=n_results,
            query_embeddings = query_embedding
        )
        if not results["documents"][0]:
            return []
        return results
    except Exception as e:
        collection = None
        print(f"Error: {e}")
        return []

