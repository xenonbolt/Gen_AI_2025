import os
from idlelib.tree import wheel_event

import chromadb
import streamlit as st
from openai import OpenAI
import chromadb.utils.embedding_functions as embedding_functions

# Set your API keys as environment variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["CHROMA_OPENAI_API_KEY"] = "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"

# Initialize chromadb client
client = chromadb.HttpClient(host="localhost", port=8080)

# Initialize OpenAI embedding function
openai_ef = embedding_functions.OpenAIEmbeddingFunction(model_name="text-embedding-3-small")

# Title of the app
st.title("Chromadb Query Console")

# Sidebar for selecting the collection name
st.sidebar.header("Select Collection Manager")
collection_name = st.sidebar.text_input("Collection Name", "document_collection")

# Try fetching the collection
try:
    collection = client.get_collection(collection_name)
except Exception as e:
    collection = None
    st.sidebar.error(f"Error: {e}")

if collection:
    # Show all items in the collection
    if st.button("Show All Items"):
        data = collection.get()
        if data.get('ids', []):
            st.write(f"Total items: {len(data['ids'])}")
            st.json(data)
        else:
            st.write("No items found.")

    # Show embeddings in the collection
    if st.button("Show Embeddings"):
        data = collection.get()
        if data.get('embeddings', []):
            st.write("Embeddings")
            st.json(data["embeddings"])
        else:
            st.write("No embeddings found.")

    # Query input
    query = st.text_input("Enter your query:", "")

    if query:
        # Generate embedding for the query using OpenAI model
        query_embedding = openai_ef([query])

        # Query the collection
        results = collection.query(
            query_embeddings=query_embedding,
            n_results=1  # You can adjust the number of results returned
        )

        # Show query results
        if results['documents']:
            st.write(f"Top {len(results['documents'])} most relevant documents:")
            for i, doc in enumerate(results['documents']):
                st.write(f"**Document {i + 1}:**")
                st.write(doc)
        else:
            st.write("No relevant documents found.")
else:
    st.write("Please enter a valid collection name and try again.")
