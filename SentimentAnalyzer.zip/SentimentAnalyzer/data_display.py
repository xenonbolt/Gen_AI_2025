import os

from langchain_openai import ChatOpenAI
from langchain_core.prompts import PromptTemplate
from langchain_core.runnables import RunnableSequence

# Set your API keys as environment variables
os.environ["OPENAI_API_KEY"] = "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"
os.environ["CHROMA_OPENAI_API_KEY"] = "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"


llm = ChatOpenAI(model="gpt-4", temperature=0)

prompt = PromptTemplate(
    input_variables=["context","question"],
    template="""
    You are an assistant. Use the context below to answer the question.
    Guardrails:
    - Do not hallucinate
    - If unsure, say 'Not enough data to answer'
    - Keep the answer concise
    
    
    Context:
    {context}
    
    
    Question:
    {question}
    
    Answer:
    """
)

# Build the chain using LCEL
chain = RunnableSequence(first=prompt, last=llm)

def generate_responses(results, questions, max_docs=5):
    docs = results["documents"][0][:max_docs]
    context = "\n".join(docs)
    response = chain.invoke({"context":context, "question":questions})
    return response.content
