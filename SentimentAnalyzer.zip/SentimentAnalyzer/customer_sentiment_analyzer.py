import streamlit as st
from data_display import generate_responses
from data_extraction import query_chroma

st.title("Sentiment Analysis")

user_query = st.text_input("Enter your query")

if st.button("Analyze"):
    with st.spinner("Analyzing..."):
        results = query_chroma(user_query)
        if results:
            final_answer = generate_responses(results, user_query)
            st.subheader("Result:")
            st.write(final_answer)
        else:
            st.error("No results found")